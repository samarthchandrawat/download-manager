Download Manager in Java
=====================

A download manager application written in Java.

##Usage
Use eclipse to open the project.

##Contact
[@luugiathuy](http://twitter.com/luugiathuy)
